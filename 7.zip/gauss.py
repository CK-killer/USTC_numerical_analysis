import numpy as np  # 引入numpy库

filename = "./matrix.dat"   # 传入的原始矩阵数据
data = np.loadtxt(filename, dtype=np.float64, delimiter=' ')    # 传入的原始矩阵数据

epsilon = 1E-7
M = 1000000

def gauss_seidel():
    m = np.mat(data)    # 将数据转换为numpy中的矩阵形式
    #print("%f" % m[0,0])
    u = np.ones(9,dtype= np.float64)
    x = np.ones(9,dtype= np.float64)
    step = 0
    for i in range(M):
        for j in range(9):
            u[j] = np.copy(x[j])
        for k in range(9):
            sum = 0
            for n in range(9):
                if(n!=k):
                    #print("%f" % m[k][n])
                    sum+=x[n]*m[k,n]
            x[k] = (m[k,9] - sum)/m[k,k]
        if(np.linalg.norm(x-u, ord = np.inf)<epsilon):
            break
    print("Gauss-Seidel Method")
    print("step = %d\n" % i)
    step = i
    for i in range(len(x)):
        print("x%d = %.15E"%(i+1,x[i]));
    # 将结果写入文件
    with open("./gauss_seidel.txt","w") as op:
        op.write("step = %d\n"%(step));
        for i in range(len(x)):
            op.write("x%d = %.15E\n"%(i+1,x[i]));
    pass

def sor():
    m = np.mat(data)    # 将数据转换为numpy中的矩阵形式
    minn = M
    omega = 0
    step = 0
    
    w = np.zeros(99,dtype= np.float64)
    for i in range(1,100):
        w[i-1] = i/50
        
    with open("./sor.txt","w") as op:
        pass
    #'''
    for l in range(0,95):
        i = 0
        u = np.ones(9,dtype= np.float64)
        x = np.ones(9,dtype= np.float64)
        for i in range(M):
            for j in range(9):
                u[j] = np.copy(x[j])
            for k in range(9):
                sum = 0
                for n in range(9):
                    if(n!=k):
                        sum+=x[n]*m[k,n]
                x[k] = u[k]*(1-w[l])+w[l]*(m[k,9] - sum)/m[k,k]
            if(np.linalg.norm(x-u, ord = np.inf)<epsilon):
                break
        if(minn > i):
            minn = i
            omega = w[l]
        step = i
        print("w = %f,step = %d"%(w[l],i))
        for i in range(len(x)):
            print("x%d = %.15E"%(i+1,x[i]));
        print("")
        
        with open("./sor.txt","a") as op:
            op.write("w = %f,step = %d\n"%(w[l],step))
            for i in range(len(x)):
                op.write("x%d = %.15E\n"%(i+1,x[i]));
            op.write("\n");
            
    print("The best w is w = %f and min step = %d"%(omega,minn))
    with open("./sor.txt","a") as op:
        op.write("the best w is w = %f"%(omega))
    
if __name__ == "__main__":
    gauss_seidel()
    sor()