import numpy as np

def func(t):
    return 0.7*np.sin(2*np.pi*2*t,dtype=np.float64)+np.sin(2*np.pi*5*t,dtype=np.float64)

def generate(n):
    d = 1/n
    fls = np.array([],dtype=np.float64)
    for i in range(n):
        fls = np.append(fls,func(i*d))
    return fls

def FFT(f):
    n = len(f)
    if n==1:
        return f
    m = (int)(n/2)
    f_odd = np.array([],dtype=np.float64)
    f_even = np.array([],dtype=np.float64)
    g_odd = np.array([],dtype=np.complex128)
    g_even = np.array([],dtype=np.complex128)
    
    g = np.zeros(n,dtype=np.complex128)
    
    w_n = np.exp(1j * (-2*np.pi/n))
    w = 1
    for i in range(m):
        f_even = np.append(f_even,f[2*i])
        f_odd = np.append(f_odd,f[2*i+1])
    g_even = FFT(f_even)
    g_odd = FFT(f_odd)
    
    for k in range(m):
        g[k] = (g_even[k] + w*g_odd[k])/2
        g[k+m] = (g_even[k] - w*g_odd[k])/2
        w *= w_n
    return g

if __name__ == "__main__":
    out1 = FFT(generate(128))
    out2 = FFT(generate(256))
    
    for i in range(len(out1)):
        print("x_i = %.15E, y_i = %.15E"%(np.real(out1[i]),np.imag(out1[i])))
    for i in range(len(out2)):
        print("x_i = %.15E, y_i = %.15E"%(np.real(out2[i]),np.imag(out2[i])))
    
    with open("./out1.txt","w") as file:
        for i in range(len(out1)):
            file.write("x_i = %.15E, y_i = %.15E\n"%(np.real(out1[i]),np.imag(out1[i])))
    file.close()
    with open("./out2.txt","w") as file:
        for i in range(len(out2)):
            file.write("x_i = %.15E, y_i = %.15E\n"%(np.real(out2[i]),np.imag(out2[i])))
    file.close()
    pass