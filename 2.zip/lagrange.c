#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define PI 3.1415926

//double型绝对值函数
double abs_d(double a){
    if(a>0){
        return a;
    }
    else{
        return -a;
    }
}

// 函数 f(x)= 1/(1+x^2)
double f(double x){
    return 1.0/(1.0+pow(x,2.0));
}

// 函数f(x)选择节点x[i]时的Lagrange插值公式于x=y[i]时的取值f(y[i])
// 参数x为选择节点的数组，len为数组的长度，y为y[i]
double lx(double *x,int len,double y){
    int i,j;
    double L,lf;
    L = 0;
    for(i=0;i<=len;i++){
        lf = 1;
        for(j=0;j<=len;j++){
            if(j!=i){
                lf *= (y-x[j])/(x[i]-x[j]);
            }
        }
        lf *= f(x[i]);
        L += lf;
    }
    return L;
}

// 最大模误差函数
// y为f(y)的数组，x为选择的节点,len为节点的数量
double max_error(double *y,double *x,int len){
    double m=0;
    double temp=0;
    int i;
    for(i=0;i<=500;i++){
        // lx(x,len,y)为Ln(yi)
        temp = abs_d(f(y[i])-lx(x,len,y[i]));
        if(temp > m){
            m = temp;
        }
    }
    return m;
}

// 主函数
void main(){
    int i,j;
    double *y;  //501个y值的数组
    double *x1; //第一组节点
    double *x2; //第二组节点
    double m1;  //第一组节点的最大模误差
    double m2;  //第二组节点的最大模误差
    int n[4] = {5,10,20,40};    //选取的节点数量

    // 初始化y节点
    y = (double *)malloc(501*sizeof(double));
    for(i=0;i<=500;i++){
        y[i] = -5 + 10*(i*1.0/500);
    }

    FILE *fp1 = NULL;
    FILE *fp2 = NULL;
    fp1 = fopen("./node1.txt","w");
    fp2 = fopen("./node2.txt","w");

    for(j=0;j<4;j++){
        // 分别初始化 x1,x2节点
        x1 = (double *)malloc((n[j]+1)*sizeof(double));
        x2 = (double *)malloc((n[j]+1)*sizeof(double));

        for(i=0;i<=n[j];i++){
            x1[i] = -5 + 10*(i*1.0/n[j]);
            x2[i] = -5*cos((2.0*i+1)*PI/(2*n[j]+2));
        }
        m1 = max_error(y,x1,n[j]);
        m2 = max_error(y,x2,n[j]);
        fprintf(fp1,"number of node = %d,max error = %.15E\n",n[j],m1);
        fprintf(fp2,"number of node = %d,max error = %.15E\n",n[j],m2);
        free(x1);
    }

    fclose(fp1);
    fclose(fp2);
}