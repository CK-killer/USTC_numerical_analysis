#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define EPS (1.0E-4)
#define DELTA (1.0E-4)

double func(double x,double y){
    //double x = p[0];
    //double y = p[1];
    return 100*pow(y-pow(x,2.0),2.0) + pow(1-x,2.0);
}

double func_px(double x,double y){
    return 400*(pow(x,2.0)-y)*x + 2*(x-1);
}

double func_py(double x,double y){
    return 200*(y-pow(x,2.0));
}

double partial(double *v,double *g){
    double x = v[0];
    double y = v[1];

    g[0] = func_px(x,y);
    g[1] = func_py(x,y);
}

double norm(double *p){
    double x = p[0];
    double y = p[1];
    return sqrt(pow(x,2.0)+pow(y,2.0));
}

double direction(double *v,double *g,double *p){
    double a = 400*(3*pow(v[0],2.0)-v[1])+2;
    double b = -400*v[0];
    double c = -400*v[0];
    double d = 200;

    p[0] = (-g[0]*d+g[1]*b)/(a*d-b*c);
    p[1] = (-g[1]*a+g[0]*c)/(a*d-b*c);
}

double golden_func(double *m,double *n){
    n[0] = m[0] + 0.382*(m[1]-m[0]);
    n[1] = m[0] + 0.618*(m[1]-m[0]);
}

double phi(double *v,double *p,double l){
    double x = v[0] + l*p[0];
    double y = v[1] + l*p[1];
    return func(x,y);
}

double golden_section(double *v,double *p){
    double m[2] = {-10,10};
    double n[2];
    int i;
    golden_func(m,n);
    for(i=0;i<=30000;i++){
        if(phi(v,p,n[0])<=phi(v,p,n[1])){
            if((n[1]-m[0])<=DELTA){
                return n[0];
            }
            else
            {
                m[1] = n[1];
                n[1] = n[0];
                n[0] = m[0] + 0.382*(m[1]-m[0]);
            }
        }
        else{
            if((m[1]-n[0])<=DELTA){
                return n[1];
            }
            else{
                m[0] = n[0];
                n[0] = n[1];
                n[1] = m[0] + 0.618*(m[1]-m[0]);
            }
        }
    }
}

void newton(){
    double v[2] = {0,0};
    double g[2];
    double p[2];
    double l;
    int k;

    FILE *fp = NULL;
    fp = fopen("./newton.txt","w");

    k = 0;
    partial(v,g);
    while (norm(g)>=EPS)
    {
        partial(v,g);
        direction(v,g,p);
        l = golden_section(v,p);
        v[0] += l*p[0];
        v[1] += l*p[1];
        k+=1;
        printf("k=%d,f(v_%d)=%.15E,x=%.15E,y=%.15E\n",k,k,func(v[0],v[1]),v[0],v[1]);
        fprintf(fp,"k=%d,f(v_%d)=%.15E,x=%.15E,y=%.15E\n",k,k,func(v[0],v[1]),v[0],v[1]);
    }
    fclose(fp);
}

void main(){
    newton();
}