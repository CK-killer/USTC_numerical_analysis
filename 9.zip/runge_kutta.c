#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double f(double x,double y){
    return -pow(x,2.0)*pow(y,2.0);
}

double yx(double x){
    return (3.0/(1+pow(x,3.0)));
}

double runge(){
    double l[4] = {0.1,0.05,0.025,0.0125};
    double x0,y0,x,y,h,k1,k2,k3,k4;
    double ok;
    double *err;
    int i,j,k;

    err = (double *)malloc(4*sizeof(double));

    FILE *fp = NULL;
    fp = fopen("./runge_kutta.txt","w");

    for(i=0;i<4;i++){
        h = l[i];
        x = 0;
        y = 0;
        x0 = 0.0;
        y0 = 3.0;
        for(k=0;k<1.5/h;k++){
            k1 = f(x,y);
            k2 = f(x+0.5*h,y+0.5*h*k1);
            k3 = f(x+0.5*h,y+0.5*h*k2);
            k4 = f(x+h,y+h*k3);
            y = y0 + (k1+2.0*k2+2.0*k3+k4)*h/6.0;
            x = x0 + h;
            
            x0 = x;
            y0 = y;
        }
        err[i] = fabs(yx(1.5) - y);
        
        if(i!=0){
            ok = log(err[i-1]/err[i])/log(2.0);
        }
        if(i == 0){
            printf("h = %lf,err = %.15E\n",h,err[i]);
            fprintf(fp,"h = %lf,err = %.15E\n",h,err[i]);
        }
        else{
            printf("h = %lf,err = %.15E,ok = %.15E\n",h,err[i],ok);
            fprintf(fp,"h = %lf,err = %.15E,ok = %.15E\n",h,err[i],ok);
        }
    }
    fclose(fp);
}

void main(){
    runge();
}
