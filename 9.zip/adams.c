#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double f(double x,double y){
    return -pow(x,2.0)*pow(y,2.0);
}

double yx(double x){
    return (3/(1+pow(x,3.0)));
}

double adams(){
    double l[4] = {0.1,0.05,0.025,0.0125};
    double x,y,ybar,h,k1,k2,k3,k4,m1;
    double ok;
    double *err,*y0;
    int i,j,k,m;

    err = (double *)malloc(4*sizeof(double));
    y0 = (double *)malloc(4*sizeof(double));

    FILE *fp = NULL;
    fp = fopen("./adams.txt","w");

    for(i=0;i<4;i++){
        h = l[i];
        x = 0;
        y = 3;
        y0[0] = 3;
        for(j=0;j<3;j++){
            k1 = f(x,y);
            k2 = f(x+h/2,y+h*k1/2);
            k3 = f(x+h/2,y+h*k2/2);
            k4 = f(x+h,y+h*k3);
            y += (k1+2*k2+2*k3+k4)*h/6;
            x += h;
            y0[j+1] = y;
        }

        for(m=0;m<1.5/h-3;m++){
            k1 = f(x,y0[3]);
            k2 = f(x-h,y0[2]);
            k3 = f(x-2*h,y0[1]);
            k4 = f(x-3*h,y0[0]);

            ybar = y + (55*k1-59*k2+37*k3-9*k4)*h/24;
            m1 = f(x+h,ybar);

            y += (9*m1+19*k1-5*k2+k3)*h/24;

            for(k=0;k<3;k++){
                y0[k] = y0[k+1];
            }
            y0[3] = y;
            x += h;
        }

        err[i] = yx(1.5) - y;
        
        if(i!=0){
            ok = log(err[i-1]/err[i])/log(2);
        }
        if(i == 0){
            printf("h = %lf,err = %.15E\n",h,err[i]);
            fprintf(fp,"h = %lf,err = %.15E\n",h,err[i]);
        }
        else{
            printf("h = %lf,err = %.15E,ok = %.15E\n",h,err[i],ok);
            fprintf(fp,"h = %lf,err = %.15E,ok = %.15E\n",h,err[i],ok);
        }
    }
    fclose(fp);
}

void main(){
    adams();
}
