import numpy as np

filename = "./matrix.dat"
data = np.loadtxt(filename,dtype=np.float64,delimiter=" ")

epsilon = 1E-8

# 求||A-diag(A)|| Fubini范数的函数
def sum(m):
    out = 0
    for i in range(5):
        for j in range(5):
            if(i!=j):
                out += m[i,j]**2
    return(out)

# 求绝对值最大非对角元素位置的函数
def max_ele(m):
    pq = []
    maxx = 0
    p = 0
    q = 0
    for i in range(4):
        for j in range(i+1,5):
            if(np.abs(m[i,j])>maxx):
                maxx = np.abs(m[i,j])
                p = i
                q = j
    pq.append(p)
    pq.append(q)
    return(pq)

# Jacobi方法主函数
def jacobi():
    m = np.mat(data)
    v = np.matrix([[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]],dtype=np.float64)
    while(sum(m)>epsilon):
        p = max_ele(m)[0]
        q = max_ele(m)[1]
        if(m[p,q]!=0):
            s = (m[q,q]-m[p,p])/(2*m[p,q])
            if(s==0):
                t = 1
            else:
                t1 = -s - np.sqrt(s**2+1)
                t2 = -s + np.sqrt(s**2+1)
                if(np.abs(t1)>np.abs(t2)):
                    t = t2
                else:
                    t = t1
            c = 1/(np.sqrt(1+t**2))
            d = t*c
        else:
            c=1
            d=0
        
        for i in range(5):
            if(i!=p and i!= q):
                m[i,p] = c*m[p,i]-d*m[q,i]
                m[i,q] = c*m[q,i]+d*m[p,i]
        for i in range(5):
            if(i!=p and i!= q):
                m[p,i] = m[i,p]
                m[q,i] = m[i,q]
        m[p,p]=m[p,p]-t*m[p,q]
        m[q,q]=m[q,q]+t*m[p,q]
        m[p,q]=0
        m[q,p]=0
        
        for i in range(5):
            v1 = v[i,p]*c-v[i,q]*d
            v2 = v[i,p]*d+v[i,q]*c
            v[i,p] = v1
            v[i,q] = v2
    # 结果输出
    for i in range(5):
        print("r%d = %.15E, v%d = "%(i+1,m[i,i],i+1))
        print(v[:,i])
        
    with open("./out.txt","w") as op:
        for i in range(5):
            op.write("r%d = %.15E, v%d = ("%(i+1,m[i,i],i+1))
            for j in range(5):
                op.write("%.15E"%(v[j,i]))
                if j!=4:
                    op.write(",")
            op.write(")\n")

if __name__ == "__main__":
    jacobi()