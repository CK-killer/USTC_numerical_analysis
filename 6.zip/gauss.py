import numpy as np  # 引入numpy库

filename = "./matrix.dat"   # 传入的原始矩阵数据
data = np.loadtxt(filename, dtype=np.float64, delimiter=' ')    # 传入的原始矩阵数据

def main():
    m = np.mat(data)    # 将数据转换为numpy中的矩阵形式
    
    # Gauss列主法第一步，会得到一个上三角矩阵
    for i in range(8):
        k = np.argmax(m[i:,i]) if m[i:,i].max() > -m[i:,i].min() else np.argmin(m[i:,i])
        k += i
        if(k!=i):
            tmp = np.copy(m[i])
            m[i] = m[k]
            m[k] = tmp
        for j in range(i+1,9):
            if(m[j,i]!=0):
                m[j] = m[j]-(m[j,i]/m[i,i])*m[i]
    #此处可以打印矩阵 m 查看具体元素
    #print(m)
    x = np.zeros(9, dtype = np.float64) # 创建储存x的数组
    
    # Gauss列主元法第二步，回带数据，得解
    for i in range(0,9):
        j = 8-i
        sum = m[j,9]
        if(j!=8):
            for k in range(j,8):
                sum += -m[j,k+1]*x[k+1]
        x[j] = sum/m[j,j]
    #print(x)
    # 打印结果
    for i in range(len(x)):
        print("x%d = %.15E"%(i+1,x[i]));
        
    # 将结果写入文件
    with open("./out.txt","w") as op:
        for i in range(len(x)):
            op.write("x%d = %.15E\n"%(i+1,x[i]));
    
if __name__ == "__main__":
    main()