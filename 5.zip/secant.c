// 弦截法
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define EPSILON 1E-8

//double型绝对值函数
double abs_d(double a){
    if(a>0){
        return a;
    }
    else{
        return -a;
    }
}

// 定义函数f(x)
double func(double x){
    return (pow(x,3.0)/3-x);
}

// 定义迭代函数\varphi(x)
double f_iter(double x1,double x2){
    return (x2-func(x2)*(x2-x1)/(func(x2)-func(x1)));
}

void main(){
    int i,j;
    double x_0[4] = {-0.1,-0.2,-2.0,0.9};   // 初始值
    double x_1[4] = {0.1,0.2,0.9,9.0};      // 初始值
    double x1,x2,tmp;

    FILE *fp = NULL;
    fp = fopen("./secant.txt","w");

    for(i=0;i<4;i++){
        // 进行迭代
        x1 = f_iter(x_0[i],x_1[i]);
        if(abs(x1-x_1[i])<EPSILON || abs_d(func(x1))<EPSILON){
            printf("x0 = %.15E,x1 = %.15E,root = %.15E,step = %d\n",x_0[i],x_1[i],x1,1);
            fprintf(fp,"x0 = %.15E,x1 = %.15E,root = %.15E,step = %d\n",x_0[i],x_1[i],x1,1);
            continue;
        }
        x2 = f_iter(x_1[i],x1);
        j = 2;
        while(abs_d(x2-x1)>(EPSILON) && abs_d(func(x2))>(EPSILON)){
            tmp = x2;
            x2 = f_iter(x1,x2);
            x1 = tmp;
            j+=1;
        }
        printf("x0 = %.15E,x1 = %.15E,root = %.15E,step = %d\n",x_0[i],x_1[i],x2,j);
        fprintf(fp,"x0 = %.15E,x1 = %.15E,root = %.15E,step = %d\n",x_0[i],x_1[i],x2,j);
    }

    fclose(fp);
}