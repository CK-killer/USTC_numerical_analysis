#include<stdio.h>
#include<stdlib.h>
#include<math.h>

void main(){
    // 待拟合数据
    double x[10] = {0.25,0.5,0.75,1.0,1.25,1.5,1.75,2.0,2.25,2.5};
    double y[10] = {1.284,1.648,2.117,2.718,3.427,2.798,3.534,4.456,5.465,5.894};
    // 变量定义
    double sx2,sxcx,cx2,sxy,cxy;
    double a,b,mse;
    int i;

    sx2 = 0;    // Sin(x)^2
    sxcx = 0;   // Sin(x)*Cos(x)
    cx2 = 0;    // Cos(x)^2
    sxy = 0;    // Sin(x)*y
    cxy = 0;    // Cos(x)*y

    // 求ATA矩阵的系数和ATb矩阵的系数
    for(i=0;i<10;i++){
        sx2 += pow(sin(x[i]),2.0);
        sxcx += sin(x[i])*cos(x[i]);
        cx2 += pow(cos(x[i]),2.0);
        sxy += sin(x[i])*y[i];
        cxy += cos(x[i])*y[i];
    }
    // 利用克莱姆法则 解线性方程组AtAx=Atb
    a = (sxy*cx2-sxcx*cxy)/(sx2*cx2-pow(sxcx,2.0));
    b = (sx2*cxy-sxy*sxcx)/(sx2*cx2-pow(sxcx,2.0));
    
    // 计算最小均方误差
    mse = 0;
    for(i=0;i<10;i++){
        mse += pow(a*sin(x[i])+b*cos(x[i])-y[i],2.0);
    }

    mse = pow(mse,0.5);
    printf("a=%0.15E,b=%.15E,mean square error=%.15E\n",a,b,mse);
    FILE *fp = NULL;
    fp = fopen("./out.txt","w");
    fprintf(fp,"a=%0.15E,b=%.15E,mean square error=%.15E\n",a,b,mse);
    fclose(fp);
}