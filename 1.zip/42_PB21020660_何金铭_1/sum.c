#include<stdio.h>
#include<math.h>

// 级数每一项的函数
double func(int k,double x){
    return(1/(k*(k+x)));
}

// 主函数
void main(){
    double error = 1E-6;    // 截断误差保留到小数点后6位
    double x[7] = {0.0,0.5,1.0,sqrt(2),10.0,100.0,300.0};   //储存输入的x的值
    double sum;             // 求和的累加器
    int N = 1100;           // K 的取值上限
    int i,j;                // 计数器

    FILE *fp = NULL;
    fp = fopen("./out.dat","w");    // 将输出结果保留至./out.dat

    for(j=0;j<7;j++){
        sum = 0;
        for(i=1;i<N;i++){
            // 若级数的一项小于截断误差，则停止循环
            if(func(i,x[j])<error){
                break;
            }
            sum += func(i,x[j]);
        }
        // 输入结果
        printf("x=%.1lf,y=%.15lf\n",x[j],sum);
        fprintf(fp,"x=%.1lf,y=%.15lf\n",x[j],sum);
    }
    fclose(fp);
}