#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define INT_A 1                 //积分下限
#define INT_B 5                 //积分上限
#define I 0.2566401204049135    //精确值

// 被积函数，此处是sin(x)，可任意修改
double func(double x){
    return sin(x);
}

// 复化梯形积分，参数分别为 函数指针p，节点数组x，节点数组个数
double t_integrate(double (*p)(double),double *x,int N){
    int i;
    double sum;
    sum = 0;
    // 代入表达式
    for(i=0;i<N;i++){
        if(i==0 || i==N-1){
            sum += 1.0*p(x[i])/2;
        }
        else{
            sum += p(x[i]);
        }
    }
    return (sum*(INT_B-INT_A)/(N-1));
}

// 复化Simpson积分，参数分别为 函数指针p，节点数组x，节点数组个数
double s_integrate(double (*p)(double),double *x,int N){
    int i;
    double sum;
    sum = 0;
    // 代入表达式
    for(i=0;i<N;i++){
        if(i==0 || i==N-1){
            sum += 1.0*p(x[i]);
        }
        else{
            if(i%2==1){
                sum += 4*p(x[i]);
            }
            else{
                sum += 2*p(x[i]);
            }
        }
    }
    return (sum*(INT_B-INT_A)/(3*(N-1)));
}

// 主函数
void main(){
    int i,j;        // 计数器
    int N;          // 暂存器，节点个数
    double i_t,i_s; // 暂存器，积分值
    double *x;      // 节点数组
    double *e_t;    // 复化梯形积分误差
    double *e_s;    // 复化Simpson积分误差
    double (*p)(double) = func; // 传入函数指针

    // 写入文件
    FILE *fp_t = NULL;
    FILE *fp_s = NULL;
    fp_t = fopen("./trapezoidal.txt","w");
    fp_s = fopen("./simpson.txt","w");

    e_t = (double *)malloc(11*sizeof(double));
    e_s = (double *)malloc(11*sizeof(double));

    for(i=1;i<=12;i++){
        N = (int)pow(2.0,i*1.0)+1;
        x = (double *)malloc(N*sizeof(double));

        i_t = 0;
        i_s = 0;

        // 初始化节点
        for(j=0;j<N;j++){
            x[j] = INT_A + 1.0*j*(INT_B-INT_A)/(N-1);
        }
        // 计算积分
        i_t = t_integrate(p,x,N);
        i_s = s_integrate(p,x,N);
        // 计算误差
        e_t[i] = I-i_t;
        e_s[i] = I-i_s;
        // 输出结果
        if(i==1){
            fprintf(fp_t,"inte = %.15E,error = %.15E\n",i_t,I-i_t);
            fprintf(fp_s,"inte = %.15E,error = %.15E\n",i_s,I-i_s);
        }
        else{
            fprintf(fp_t,"inte = %.15E,error = %.15E,e_order = %.15E\n",i_t,I-i_t,log(e_t[i-1]/e_t[i])/log(2));
            fprintf(fp_s,"inte = %.15E,error = %.15E,e_order = %.15E\n",i_s,I-i_s,log(e_s[i-1]/e_s[i])/log(2));
        }
        free(x);
    }

    fclose(fp_t);
    fclose(fp_s);
}